function getLogin(email) {

    if (email == '') {
        $('#login-email').text("");
        $('#login-senha').text("");
        $(".login_submit").prop("disabled", true);
    } else {
        $('#edit-serv-id').text(id);
        fetch(`${URL}/${id}`).then(res => res.json())
            .then(data => {
                $("#service-id").prop("disabled", true);
                $('#service-id').val(data.id);
                $('#service-name').val(data.nome);
                $('#service-price').val(data.valor);
            });
    }
}